function love.conf(t)
    t.window = false
end
