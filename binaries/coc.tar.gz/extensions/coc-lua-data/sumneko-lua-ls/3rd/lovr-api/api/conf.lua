function lovr.conf(t)
  t.modules.graphics = false
  t.modules.headset = false
end
