# list
a = [
    1, 2,
    3
]

# set
b = {
    3,
    4,
}

# dict
c = {
    'a': 'b',
    'c': 1,
}

# tuple
d = (
    1,
    2,
)
