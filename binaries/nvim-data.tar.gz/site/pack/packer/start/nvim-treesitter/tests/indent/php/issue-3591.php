<?php

function test() {
    $array = [
}
