html`<p></p>`;
   // ^ html
html(`<p></p>`);
   // ^ html
svg`<p></p>`;
   // ^ html
svg(`<p></p>`);
   // ^ html

