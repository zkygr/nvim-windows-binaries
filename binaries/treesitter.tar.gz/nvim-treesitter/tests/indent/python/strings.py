a = """
    String A
"""

b = """
String B
"""

c = """
    String C
    """

d = """
    String D
String D
        String D
    """
