function test(a::Number,
              b::Float64,
              c::Union{Float64, Integer},
              d::Bool)
end

function test(
    a::Number,
    b::Float64,
    c::Union{Float64, Integer},
    d::Bool
)
end
